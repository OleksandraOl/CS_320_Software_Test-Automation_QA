package contact;

import java.util.concurrent.atomic.AtomicInteger;


public class Contact {
	//declare fields
	private final String contactID; //shouldn't be updatable
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	private static final AtomicInteger uniqueContactID = new AtomicInteger(1);
	
	//method to generate unique contact ID
	private String getNewId() {
		String uniqueID = String.valueOf(uniqueContactID.getAndIncrement());
		
		//check if the generated id exceeds the 10 char limit
		if (uniqueID.length() > 10) {
			throw new IllegalStateException("ID exceeds 10 characters. Please contact support.");
		}
		return uniqueID;
	}
	
	//method to check if the input include digits only
	public boolean isDigitsOnly(String phoneNumber) {
		for (int i = 0; i < phoneNumber.length(); i++) {
			if (Character.isDigit(phoneNumber.charAt(i))) {
				continue;
			}
			else {
				return false;
			}
		}
		
		return true;
	}
	
	//constructor
	public Contact (String firstName, String lastName, String phone, String address) {
		//check for null values
		if (firstName == null || lastName == null || phone == null || address == null) {
			throw new IllegalArgumentException("Input is invalid. Fields can not be null");
		}
		
		//remove the leading and trailing whitespaces of the input
		firstName = firstName.trim();
		lastName = lastName.trim();
		phone = phone.trim();
		address = address.trim();
		
		//check the correctness of the first name
		if (firstName.isEmpty() || firstName.length() > 10) {
			throw new IllegalArgumentException("First name is invalid. The field cannot be empty or longer than 10 characters.");
		}
		
		//check the correctness of the last name
		if (lastName.isEmpty() || lastName.length() > 10) {
			throw new IllegalArgumentException("Last name is invalid. The field cannot be empty or longer than 10 characters.");
		}
		
		//check the correctness of the phone number
		if (phone.isEmpty() || !isDigitsOnly(phone) || phone.length() != 10) {
			throw new IllegalArgumentException("Phone is invalid. The phone number cannot be empty and should be 10 digits only.");
		}
		
		//check the correctness of the address
		if (address.isEmpty() || address.length() > 30) {
			throw new IllegalArgumentException("Address is invalid. The field cannot be empty or longer than 30 characters.");
		}
		
		this.contactID = getNewId();
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	//constructors to handle missing parameters errors
	public Contact() {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	public Contact(String firstName) {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	public Contact(String firstName, String lastName) {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	public Contact(String firstName, String lastName, String phone) {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	
	//getters
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	//setters, the conditions for the input are the same as in the constructor
	public void setFirstName(String firstName) {
		//check for null value
		if (firstName == null) {
			throw new IllegalArgumentException("First name is invalid. The field cannot be null.");
		}
		//remove the leading and trailing whitespaces of the input
		firstName = firstName.trim();
		
		//check the correctness
		if (firstName.isEmpty() || firstName.length() > 10) {
			throw new IllegalArgumentException("First name is invalid. The field cannot be empty or longer than 10 characters.");
		}
		
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		//check for null value
		if (lastName == null) {
			throw new IllegalArgumentException("Last name is invalid. The field cannot be null.");
		}
		
		//remove the leading and trailing whitespaces of the input
		lastName = lastName.trim();

		//check the correctness
		if (lastName.isEmpty() || lastName.length() > 10) {
			throw new IllegalArgumentException("Last name is invalid. The field cannot be empty or longer than 10 characters.");
		}
		
		this.lastName = lastName;
	}
	
	public void setPhone(String phone) {
		//check for null value
		if (phone == null) {
			throw new IllegalArgumentException("Phone is invalid. The field cannot be null.");
		}
				
		//remove the leading and trailing whitespaces of the input
		phone = phone.trim();
		
		//check the correctness
		if (phone.isEmpty() || !isDigitsOnly(phone) || phone.length() != 10) {
			throw new IllegalArgumentException("Phone is invalid. The phone number cannot be empty and should be 10 digits only.");
		}
		
		this.phone = phone;
	}
	
	public void setAddress(String address) {
		//check for null value
		if (address == null) {
			throw new IllegalArgumentException("Address is invalid. The field cannot be null.");
		}
		//remove the leading and trailing whitespaces of the input
		address = address.trim();
		
		//check the correctness
		if (address.isEmpty() || address.length() > 30) {
			throw new IllegalArgumentException("Address is invalid. The field cannot be empty or longer than 30 characters.");
		}
		
		this.address = address;
	}
	
	
}

