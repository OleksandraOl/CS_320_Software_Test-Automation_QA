package contact;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;



public class ContactService {
	
	//create a hash map to store contacts	
	private HashMap<String, Contact> contactMap = new HashMap<>();	
	private List<String> contactIDs = new ArrayList<>();
	
	// method to check if the input ID is valid:
	public void checkInputIDValidity(String inputID) {
		if (inputID == null) {
			throw new IllegalArgumentException("The contact ID can't be null.");
		}
		inputID = inputID.trim();
		
		if (inputID.isEmpty() || inputID.length() > 10) {
			throw new IllegalArgumentException("The contact ID can't be empty/null or more than 10 characters long.");
		}		
	}
	
	//method to throw exception if the contact with the input ID is not in the contact list
	private void throwExceptionContactNotInSystem() {
		throw new IllegalArgumentException("This ID is not in the contact list");
	}
	
	//method to display info for testing purposes
	public void displayContacts() {
		for (String key: contactMap.keySet()) {
			System.out.println("ID: " + key + ", name: " + contactMap.get(key).getFirstName() + ", last name: " + contactMap.get(key).getLastName() + ", phone: " + contactMap.get(key).getPhone() +
					", address: " + contactMap.get(key).getAddress());
			
		}
	}
	//method to get unique ids for testing purposes
	public List<String> getContactIDs() {
		return new ArrayList<>(contactIDs);
	} 
	
	//method to get a contact for testing pursposes
	public Contact getContact(String inputContactID) {
		checkInputIDValidity(inputContactID);
		if (!contactMap.containsKey(inputContactID)) {
			throw new IllegalArgumentException("This ID is not in the system.");
		}
		else {
			return contactMap.get(inputContactID);
		}
	}
	
	//handle missing parameters errors (no parameters)
	public void addNewContact() {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	//handle missing parameters errors (one parameter)
	public void addNewContact(String firstName) {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	//handle missing parameters errors (two parameters)
	public void addNewContact(String firstName, String lastName) {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	//handle missing parameters errors (two parameters)
	public void addNewContact(String firstName, String lastName, String phone) {
		throw new IllegalArgumentException("Input is invalid. All fields should be fiiled out.");
	}
	
	//add contact
	public void addNewContact(String firstName, String lastName, String phone, String address) {
		//create an instance of contact
		//Contact class will handle the input and exceptions
		Contact contact = new Contact(firstName, lastName, phone, address);
		if (contactMap.containsKey(contact.getContactID())) {
			throw new IllegalArgumentException("This ID already exists in the system. Please try again or contact support team.");
		}
		
		//add new contact to the hash map
		contactMap.put(contact.getContactID(), contact);
		contactIDs.add(contact.getContactID());
		
		System.out.println("The new contact has been added.");
	}
	
	//delete contact
	public void deleteContact(String inputContactID) {	
		//check if the input is valid
		checkInputIDValidity(inputContactID);
		
		//check if the ID exists in the system
		if (contactMap.containsKey(inputContactID)) {
			contactMap.remove(inputContactID);
		}
		else {
			throwExceptionContactNotInSystem();
		}
		
		System.out.println("The contact with the ID: " + inputContactID + " has been successfully removed.");
	}
	
	//update first name
	public void updateFirstName(String inputContactID, String updatedFirstName) {
		//check the input ID validity
		checkInputIDValidity(inputContactID);
		
		//the setter will check the value of the input name
		//check if the ID exists in the system
		if (contactMap.containsKey(inputContactID)) {
			contactMap.get(inputContactID).setFirstName(updatedFirstName);
		}
		else {
			throwExceptionContactNotInSystem();
		}
		
		System.out.println("The first name of the contact with the ID: " + inputContactID + " has been successfully changed to " + updatedFirstName + ".");		
	}
	
	//update last name
	public void updateLastName(String inputContactID, String updatedLastName) {
		//check the input ID validity
		checkInputIDValidity(inputContactID);
		
		//the setter will check the value of the input last name
		//check if the ID exists in the system
		if (contactMap.containsKey(inputContactID)) {
			contactMap.get(inputContactID).setLastName(updatedLastName);
		}
		else {
			throwExceptionContactNotInSystem();
		}
		
		System.out.println("The last name of the contact with the ID: " + inputContactID + " has been successfully changed to " + updatedLastName + ".");			
	}
	
	//update phone
	public void updatePhone(String inputContactID, String updatedPhone) {
		//check the input ID validity
		checkInputIDValidity(inputContactID);
		
		//the setter will check the value of the input phone
		//check if the ID exists in the system
		if (contactMap.containsKey(inputContactID)) {
			contactMap.get(inputContactID).setPhone(updatedPhone);
		}
		else {
			throwExceptionContactNotInSystem();
		}
		
		System.out.println("The phone of the contact with the ID: " + inputContactID + " has been successfully changed to " + updatedPhone + ".");			
	}
	
	//update address
	public void updateAddress(String inputContactID, String updatedAddress) {
		//check the input ID validity
		checkInputIDValidity(inputContactID);
		
		//the setter will check the value of the input address
		//check if the ID exists in the system
		if (contactMap.containsKey(inputContactID)) {
			contactMap.get(inputContactID).setAddress(updatedAddress);
		}
		else {
			throwExceptionContactNotInSystem();
		}
		
		System.out.println("The address of the contact with the ID: " + inputContactID + " has been successfully changed to " + updatedAddress + ".");			
	}
	
}