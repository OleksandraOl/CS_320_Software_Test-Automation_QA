package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;

import contact.ContactService;

import org.junit.jupiter.api.Test;

class ContactServiceTest {
	
	//check contact adding
	@Test
	void testAddingContact() {
		ContactService newContact = new ContactService();
		newContact.addNewContact("John", "Smith", "2563698536", "25 Lane Blue, Spring");
		newContact.displayContacts();
		
		newContact.addNewContact("Alice", "Bowley", "2573698539", "25 Crane Yellow");
		newContact.displayContacts();
		
		newContact.addNewContact("Bill", "Ryan", "2579998539", "25 Crane Green");
		newContact.displayContacts();
		
		newContact.addNewContact("Luis", "Green", "5559998539", "95 Crane Red");
		newContact.displayContacts();
	}	
	
	//check the method to evaluate the inputID (more than 10 characters)
	@Test
	void testInputIDEvaluationTooLong() {
		ContactService contact = new ContactService();
		contact.addNewContact("John", "Smith", "2563698536", "25 Lane Blue, Spring");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.checkInputIDValidity("96968969869");
		});
	}
		
	//check the method to evaluate the inputID(null)
	@Test
	void testInputIDEvaluationNull() {
		ContactService contact = new ContactService();
		contact.addNewContact("John", "Smith", "2563698536", "25 Lane Blue, Spring");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.checkInputIDValidity(null);
		});
	}
	
	//check the method to evaluate the inputID(empty)
	@Test
	void testInputIDEvaluationEmpty() {
		ContactService contact = new ContactService();
		contact.addNewContact("John", "Smith", "2563698536", "25 Lane Blue, Spring");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.checkInputIDValidity(" ");
		});
	}
	
	//test constructor with missing parameters
	
	//adding a contact with no parameters
	@Test
	void testAddingInvalidContactNoParameters() {
		ContactService contact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.addNewContact();
		});
	}
	//adding a contact with 1 parameters (name)
	@Test
	void testAddingInvalidContactOneParameter() {
		ContactService contact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.addNewContact("Bohdan");
		});
	}
	//adding a contact with 2 parameters (name, last name)
	@Test
	void testAddingInvalidContactTwoParameters() {
		ContactService contact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.addNewContact("Bohdan", "Levovych");
		});
	}
	//adding a contact with 2 parameters (name, last name, phone number)
	@Test
	void testAddingInvalidContactThreeParameters() {
		ContactService contact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.addNewContact("Bohdan", "Levovych", "5698695869");
		});
	}
	
	
	//FIRST NAME
	//first name is too long
	@Test
	void testAddingInvalidContactNameTooLong() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("Oleksiivnaa", "Smith", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	//first name is of correct length with extra whitespaces
	@Test
	void testAddingInvalidContactNameExtraSpaces() {
		ContactService newContact = new ContactService();
		
		Assertions.assertDoesNotThrow(() -> {
			newContact.addNewContact("  Julieta   ", "Smith", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	//first name is null
	@Test
	void testAddingInvalidContactNameNull() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact(null, "Smith", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	//first name is empty
	@Test
	void testAddingInvalidContactNameEmpty() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact(" ", "Smith", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	
	//LAST NAME
	//last name is too long
	@Test
	void testAddingInvalidContactLastNameTooLong() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("John", "Smithfieldbruno", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	//last name is correct length with extra whitespaces
	@Test
	void testAddingInvalidContactLastNameExtraSpaces() {
		ContactService newContact = new ContactService();
		
		Assertions.assertDoesNotThrow(() -> {
			newContact.addNewContact("John", "            Smith", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	//last name is null
	@Test
	void testAddingInvalidContactLastNameNull() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("John", null, "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	//last name is empty
	@Test
	void testAddingInvalidContactLastNameEmpty() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("John", "  ", "2563698536", "25 Lane Blue, Spring");
		});
	}
	
	
	//PHONE
	//phone number is too long
	@Test
	void testAddingInvalidContactPhoneTooLong() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("Luis", "Green", "55599953965", "95 Crane Red");
		});
	}
	
	//phone number is too short
	@Test
	void testAddingInvalidContactPhoneTooShort() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("Luis", "Green", "599953965", "95 Crane Red");
		});
	}
	
	//phone number consists not of digits only
	@Test
	void testAddingInvalidContactPhoneNotDigits() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("Luis", "Green", "599953'965", "95 Crane Red");
		});
	}
	
	//phone number is of correct length with extra whitespaces
	@Test
	void testAddingInvalidContactPhoneExtraSpaces() {
		ContactService newContact = new ContactService();
		
		Assertions.assertDoesNotThrow(() -> {
			newContact.addNewContact("Luis", "Green", "5559995396   ", "95 Crane Red");
		});
	}
	
	//phone number is null
	@Test
	void testAddingInvalidContactPhoneNull() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("Luis", "Green", null, "95 Crane Red");
		});
	}
	
	//phone number is empty
	@Test
	void testAddingInvalidContactPhoneEmpty() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("Luis", "Green", "  ", "95 Crane Red");
		});
	}
	
	
	//ADDRESS
	//address is too long
	@Test
	void testAddingInvalidContactAddressTooLong() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("John", "Smithfiel", "2563698536", "25 Lane Blue, Spring, Summer Fall");
		});
	}
	
	//address is of correct length with extra whitespaces
	@Test
	void testAddingInvalidContactAddressExtraSpaces() {
		ContactService newContact = new ContactService();
		
		Assertions.assertDoesNotThrow(() -> {
			newContact.addNewContact("John", "Smithfiel", "2563698536", "           25 Lane Blue, Spring");
		});
	}
	
	//address is null
	@Test
	void testAddingInvalidContactAddressNull() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("John", "Smithfiel", "2563698536", null);
		});
	}
	
	//address is empty
	@Test
	void testAddingInvalidContactAddressEmpty() {
		ContactService newContact = new ContactService();
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.addNewContact("John", "Smithfiel", "2563698536", "");
		});
	}
	
	
	//DELETING contacts
	@Test
	void testDeletingContact() {
		ContactService contact = new ContactService();

		contact.addNewContact("Grey", "Smith", "8883698536", "25 Lane Blue, Spring");		
		contact.addNewContact("Alice", "Bowley", "2573669339", "25 Crane Blue");
		contact.addNewContact("Bill", "Doe", "2578968539", "25 Crane Green");
		contact.addNewContact("Jane", "Doe", "2579998539", "25 Millo Green");
		
		String contactAtIndex3 = contact.getContactIDs().get(2);
		contact.deleteContact(contactAtIndex3);
		
		String contactAtIndex0 = contact.getContactIDs().get(0);
		contact.deleteContact(contactAtIndex0);
		
		//check if the contact with the same id still exists
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.getContact(contactAtIndex3);
		});
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.getContact(contactAtIndex0);
		});
	}
	
	//UPDATING FIRST NAME with valid inputs
	@Test 
	void testUpdatingFirstName() {
		ContactService contact = new ContactService();

		contact.addNewContact("John", "Smithh", "2563588536", "36 Lane Blue, Spring");		
		contact.addNewContact("Alice", "Bowley", "2573698539", "25 Meow Yellow");
		contact.addNewContact("Bill", "Doe", "6399998539", "25 Crane Brown");
		contact.addNewContact("Jane", "Doe", "2222998539", "90 Yellow Green");
		
		String person1ID = contact.getContactIDs().get(0);
		String person2ID = contact.getContactIDs().get(1);
		
		contact.updateFirstName(person1ID, "Bill");
		assertTrue(contact.getContact(person1ID).getFirstName().equals("Bill"));
		assertTrue(contact.getContact(person1ID).getLastName().equals("Smithh"));
		assertTrue(contact.getContact(person1ID).getPhone().equals("2563588536"));
		assertTrue(contact.getContact(person1ID).getAddress().equals("36 Lane Blue, Spring"));
		
		contact.updateFirstName(person2ID, "Mykhailo");
		assertTrue(contact.getContact(person2ID).getFirstName().equals("Mykhailo"));
		assertTrue(contact.getContact(person2ID).getLastName().equals("Bowley"));
		assertTrue(contact.getContact(person2ID).getPhone().equals("2573698539"));
		assertTrue(contact.getContact(person2ID).getAddress().equals("25 Meow Yellow"));

	}
	
	//updating first name invalid ID
	@Test
	void testUpdatingFirstNameInvalidID () {
		ContactService contact = new ContactService();
		contact.addNewContact("John", "Smithh", "2563588536", "36 Lane Blue, Spring");	
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateFirstName("998969896", "Brianna");		
		});	
	}
	
	//invalid inputs
	//updating - first name is too long
	@Test
	void testUpdatingFirstNameInvalidTooLong() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateFirstName(person1ID, "OlhaMyronenkoBlanchard");
		});
	}
	
	//updating - first name is of correct length, extra whitespaces
	@Test
	void testUpdatingFirstNameInvalidExtraWhitespaces() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertDoesNotThrow(() -> {
			contact.updateFirstName(person1ID, "OlhaMyro             ");
		});
		
		contact.getContact(person1ID).getFirstName().equals("OlhaMyro");
	}
	
	//updating - first name is null
	@Test
	void testUpdatingFirstNameInvalidNull() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateFirstName(person1ID, null);
		});
	}
	
	//updating - first name is empty
	@Test
	void testUpdatingFirstNameInvalidEmpty() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateFirstName(person1ID, "    ");
		});
	}	

	
	//UPDATING LAST NAME
	@Test 
	void testUpdatingLastName() {
		ContactService contact = new ContactService();

		contact.addNewContact("John", "Smithh", "2563588536", "36 Lane Blue, Spring");		
		contact.addNewContact("Alice", "Bowley", "2573698539", "25 Meow Yellow");
		contact.addNewContact("Bill", "Doe", "6399998539", "25 Crane Brown");
		contact.addNewContact("Jane", "Doe", "2222998539", "90 Yellow Green");
		
		String person1ID = contact.getContactIDs().get(0);
		String person3ID = contact.getContactIDs().get(2);
		
		contact.updateLastName(person1ID, "Myronenko");
		assertTrue(contact.getContact(person1ID).getFirstName().equals("John"));
		assertTrue(contact.getContact(person1ID).getLastName().equals("Myronenko"));
		assertTrue(contact.getContact(person1ID).getPhone().equals("2563588536"));
		assertTrue(contact.getContact(person1ID).getAddress().equals("36 Lane Blue, Spring"));
		
		contact.updateLastName(person3ID, "Oleksiinko");
		assertTrue(contact.getContact(person3ID).getFirstName().equals("Bill"));
		assertTrue(contact.getContact(person3ID).getLastName().equals("Oleksiinko"));
		assertTrue(contact.getContact(person3ID).getPhone().equals("6399998539"));
		assertTrue(contact.getContact(person3ID).getAddress().equals("25 Crane Brown"));
	}
	
	
	//invalid input
	//updating - last name is too long
	@Test
	void testUpdatingLastNameInvalidTooLong() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateLastName(person1ID, "OlhaMyronenBlanchard");
		});
	}
	
	//updating - last name is of correct length, extra whitespaces
	@Test
	void testUpdatingLastNameInvalidExtraWhitespaces() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertDoesNotThrow(() -> {
			contact.updateLastName(person1ID, "     Myrop   ");
		});
		
		contact.getContact(person1ID).getLastName().equals("Myrop");
	}
	
	//updating - last name is null
	@Test
	void testUpdatingLastNameInvalidNull() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateLastName(person1ID, null);
		});
	}
	
	//updating - last name is empty
	@Test
	void testUpdatingLastNameInvalidEmpty() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateLastName(person1ID, " ");
		});
	}
	
	
	//UPDATING PHONE NUMBER
	@Test 
	void testUpdatingPhone() {
		ContactService contact = new ContactService();

		contact.addNewContact("John", "Smithh", "2563588536", "36 Lane Blue, Spring");		
		contact.addNewContact("Alice", "Bowley", "2573698539", "25 Meow Yellow");
		
		String person1ID = contact.getContactIDs().get(0);
		String person2ID = contact.getContactIDs().get(1);
		
		contact.updatePhone(person1ID, "5555555555");
		assertTrue(contact.getContact(person1ID).getFirstName().equals("John"));
		assertTrue(contact.getContact(person1ID).getLastName().equals("Smithh"));
		assertTrue(contact.getContact(person1ID).getPhone().equals("5555555555"));
		assertTrue(contact.getContact(person1ID).getAddress().equals("36 Lane Blue, Spring"));
		
		contact.updatePhone(person2ID, "9999999999");
		assertTrue(contact.getContact(person2ID).getFirstName().equals("Alice"));
		assertTrue(contact.getContact(person2ID).getLastName().equals("Bowley"));
		assertTrue(contact.getContact(person2ID).getPhone().equals("9999999999"));
		assertTrue(contact.getContact(person2ID).getAddress().equals("25 Meow Yellow"));
	}
	
	//invalid inputs
	//updating - phone number is too long
	@Test
	void testUpdatingPhoneInvalidTooLong() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updatePhone(person1ID, "26395698632");
		});
	}
	
	//updating - phone number is too short
	@Test
	void testUpdatingPhoneInvalidTooShort() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updatePhone(person1ID, "263956986");
		});
	}
	
	//updating - phone number consists of not digits only
	@Test
	void testUpdatingPhoneInvalidNotDigits() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updatePhone(person1ID, "26395698.6");
		});
	}
	
	//updating - phone number is of correct length, extra whitespaces
	@Test
	void testUpdatingPhoneInvalidExtraWhitespaces() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertDoesNotThrow(() -> {
			contact.updatePhone(person1ID, "     6395698695   ");
		});
		
		contact.getContact(person1ID).getPhone().equals("6395698695");
	}
	
	//updating - phone number is null
	@Test
	void testUpdatingPhoneInvalidNull() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updatePhone(person1ID, null);
		});
	}
	
	//updating - phone number is empty
	@Test
	void testUpdatingPhoneInvalidEmpty() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updatePhone(person1ID, "");
		});
	}
	
	
	//UPDATING the ADDRESS
	@Test 
	void testUpdatingAddress() {
		ContactService contact = new ContactService();

		contact.addNewContact("John", "Smithh", "2563588536", "36 Lane Blue, Spring");		
		contact.addNewContact("Alice", "Bowley", "2573698539", "25 Meow Yellow");
		
		String person1ID = contact.getContactIDs().get(0);
		String person2ID = contact.getContactIDs().get(1);
		
		contact.updateAddress(person1ID, "6968 Bluesville");
		assertTrue(contact.getContact(person1ID).getFirstName().equals("John"));
		assertTrue(contact.getContact(person1ID).getLastName().equals("Smithh"));
		assertTrue(contact.getContact(person1ID).getPhone().equals("2563588536"));
		assertTrue(contact.getContact(person1ID).getAddress().equals("6968 Bluesville"));
		
		contact.updateAddress(person2ID, "Khmelyove 695");
		assertTrue(contact.getContact(person2ID).getFirstName().equals("Alice"));
		assertTrue(contact.getContact(person2ID).getLastName().equals("Bowley"));
		assertTrue(contact.getContact(person2ID).getPhone().equals("2573698539"));
		assertTrue(contact.getContact(person2ID).getAddress().equals("Khmelyove 695"));
	}
	
	//invalid input
	//updating - address is too long
	@Test
	void testUpdatingAddressInvalidTooLong() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateAddress(person1ID, "636985698 Blues Yellow Brown Yellow Green");
		});
	}
	
	//updating - address is of correct length, extra whitespaces
	@Test
	void testUpdatingAddressInvalidExtraWhitespaces() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertDoesNotThrow(() -> {
			contact.updateAddress(person1ID, "      25 Lane Yellow Blue     ");
		});
		
		contact.getContact(person1ID).getAddress().equals("25 Lane Yellow Blue");
	}
	
	//updating - address is null
	@Test
	void testUpdatingAddressInvalidNull() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateAddress(person1ID, null);
		});
	}
	
	//updating - address is empty
	@Test
	void testUpdatingAddressInvalidEmpty() {
		ContactService contact = new ContactService();
		contact.addNewContact("Anabelle", "Myro", "2569999536", "19 Lane");	
		
		String person1ID = contact.getContactIDs().get(0);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			contact.updateAddress(person1ID, " ");
		});
	}


}
