package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.Contact;


class ContactTest {
	
	//test the constructor of the Contact class
	@Test
	void testContactClass1() {
		Contact contact = new Contact ("John", "Smith", "3653565885", "25 S Lane Yellow");
		//check if the id was generated
		assertNotNull(contact.getContactID());
		assertTrue(contact.getFirstName().equals("John"));
		assertTrue(contact.getLastName().equals("Smith"));
		assertTrue(contact.getPhone().equals("3653565885"));
		assertTrue(contact.getAddress().equals("25 S Lane Yellow"));
	}
	
	@Test
	void testContactClass2() {
		Contact contact = new Contact ("Bill", "Junior", "3659995885", "50 N Lane Blue");
		//check if the id was generated
		assertNotNull(contact.getContactID());
		assertTrue(contact.getFirstName().equals("Bill"));
		assertTrue(contact.getLastName().equals("Junior"));
		assertTrue(contact.getPhone().equals("3659995885"));
		assertTrue(contact.getAddress().equals("50 N Lane Blue"));
	}
	
	//test EXTRA CONSTRUCTORS of the Contact class to handle missing parameter error
	
	//constructor has no parameters
	@Test
	void testContactClassNoParameters() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact ();
		});
	}
	
	//constructor has 1 parameter only (name)
	@Test
	void testContactClassOneParameters() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact ("Julie");
		});
	}
	
	//constructor has 2 parameters (name, last name)
	@Test
	void testContactClassTwoParameters() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact ("Julie", "Bank");
		});
	}
	
	//constructor has 3 parameters (name, last name, phone number) 
	@Test
	void testContactClassThreeParameters() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact ("Julie", "Bank", "56986985695");
		});
	}
	
	//CONTACTID
	//ensure the generated contact ids are unique
	@Test
	void testUniqnuessOfCntactID() {
		HashMap<String, Integer> mapID = new HashMap<>();
		
		for (int i = 0; i < 10000; i++) {
			Contact contact = new Contact("Alice", "Walls", "3652698563", "56 Lane Blue");
			//id shouldn't be more than 10 characters long
			assertTrue(contact.getContactID().length() <= 10);
			//id shouldn't be empty
			assertFalse(contact.getContactID().isEmpty());
			//id shouldn't be null
			assertNotNull(contact.getContactID());
			
			//check for uniqueness
			assertFalse(mapID.containsKey(contact.getContactID()));
			
			//add the value to the map 
			mapID.put(contact.getContactID(), 1);
		}
		
	}
	
	//FIRST NAME
	//set first name
	@Test
	void testSetFirstName1() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setFirstName("Alice");
		assertTrue(contact.getFirstName().equals("Alice"));
	}
	

	@Test
	void testSetFirstName2() {
		Contact contact = new Contact("Claudia", "Prob", "3653557885", "25 S Lane Brown");
		contact.setFirstName("Card");
		assertTrue(contact.getFirstName().equals("Card"));
	}
	
	//first name is too long
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("JohnathanSm", "Smith", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) first name is too long
	@Test
	void testFirstNameTooLongSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setFirstName("AliceJohnathan");
		});
	}
		
	//first name is a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testFirstNameOverTheLimitWhitespaces() {
		Assertions.assertDoesNotThrow(() -> {
			new Contact("       John     ", "Smith", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) first name is a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testFirstNameOverTheLimitWhitespacesSetter() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setFirstName("JohnathanB ");
		assertTrue(contact.getFirstName().equals("JohnathanB"));
	}
		
	//first name is null
	@Test
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Smith", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) first name is null 
	@Test
	void testFirstNameIsNullSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setFirstName(null);
		});
	}
		
	//first name is empty
	@Test
	void testFirstNameIsEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("", "Smith", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) first name is empty 
	@Test
	void testFirstNameIsEmptySetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setFirstName(" ");
		});
	}
	
	
	//LAST NAME
	//set last name
	@Test
	void testSetLastName1() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setLastName("Wallgreen");
		assertTrue(contact.getLastName().equals("Wallgreen"));
	}
	@Test
	void testSetLastName2() {
		Contact contact = new Contact("Gregory", "Shol", "3656225885", "25 S Circle Yellow");
		contact.setLastName("Moon");
		assertTrue(contact.getLastName().equals("Moon"));
	}
	
	//last name is too long
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "SmithWallgr", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) last name is too long 
	@Test
	void testLastNameTooLongSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setLastName("JohnsonGree");
		});
	}
		
	//last name is a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testLastNameOverTheLimitWhitespaces() {
		Assertions.assertDoesNotThrow(() -> {
			new Contact("Johnathan", "         Smith", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) last name is a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testLastNameOverTheLimitWhitespacesSetter() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setLastName(" JohnsonGre  ");
		assertTrue(contact.getLastName().equals("JohnsonGre"));
	}
		
	//last name is null
	@Test
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", null, "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) last name is null 
	@Test
	void testLastNameIsNullSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setLastName(null);
		});
	}
		
	//last name is empty
	@Test
	void testLastNameIsEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", " ", "3653565885", "25 S Lane Yellow");
		});
	}
	//(setter) last name is empty 
	@Test
	void testLastNameIsEmptySetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setLastName("");
		});
	}
	
	
	//PHONE
	//set phone number
	@Test
	void testSetPhone1() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setPhone("3653559999");
		assertTrue(contact.getPhone().equals("3653559999"));
	}
	@Test
	void testSetPhone2() {
		Contact contact = new Contact("Alice", "Pier", "1153565885", "25 S Full Circle");
		contact.setPhone("3653559444");
		assertTrue(contact.getPhone().equals("3653559444"));
	}
	
	//phone number is too long
	@Test
	void testPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "36535658856", "25 S Lane Yellow");
		});
	}
	//(setter) phone number is too long 
	@Test
	void testPhoneTooLongSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "36535658856", "25 S Lane Yellow");
			contact.setPhone("35696589621");
		});
	}
	
	//phone number is too short
	@Test
	void testPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "365356588", "25 S Lane Yellow");
		});
	}
	//(setter) phone number is too short 
	@Test
	void testPhoneTooShortSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "365356588", "25 S Lane Yellow");
			contact.setPhone("653");
		});
	}
		
	//phone number is of a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testPhoneOverTheLimitWhitespaces() {
		Assertions.assertDoesNotThrow(() -> {
			new Contact("Johnathan", "Smith", "3653565885   ", "25 S Lane Yellow");
		});
	}
	//(setter) phone number is of a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testPhoneOverTheLimitWhitespacesSetter() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setPhone(" 6593625621   ");
		assertTrue(contact.getPhone().equals("6593625621"));
	}
	
	//phone number is of an incorrect length with the extra whitespace (length of 10)
	@Test
	void testPhoneUnderTheLimitWhitespaces() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "36535658  ", "25 S Lane Yellow");
		});
	}
	//(setter) phone number is of an incorrect length with the extra whitespace (length of 10) 
	@Test
	void testPhoneUnderTheLimitWhitespacesSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "6523652987", "25 S Lane Yellow");
			contact.setPhone("36535658  ");
		});
	}
	
	//the phone include other characters except for digits
	@Test
	void testPhoneIncludeNotDigits() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "36535658p]", "25 S Lane Yellow");
		});
	}
	//(setter) the phone include other characters except for digits
	@Test
	void testPhoneIncludeNotDigitsSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "6596958623", "25 S Lane Yellow");
			contact.setPhone("/653565865");
		});
	}
		
	//phone number is null
	@Test
	void testPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", null, "25 S Lane Yellow");
		});
	}
	//(setter) phone number is null
	@Test
	void testPhoneIsNullSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "6596958623", "25 S Lane Yellow");
			contact.setPhone(null);
		});
	}
		
	//phone number is empty
	@Test
	void testPhoneNameIsEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "", "25 S Lane Yellow");
		});
	}
	//(setter) phone number is empty
	@Test
	void testPhoneNameIsEmptySetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", null, "25 S Lane Yellow");
			contact.setPhone("");
		});
	}
	
	
	//ADDRESS
	//set address
	@Test
	void testSetAddress1() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setAddress("639 Point Drive");
		assertTrue(contact.getAddress().equals("639 Point Drive"));
	}
	@Test
	void testSetAddress2() {
		Contact contact = new Contact("Gregory", "Williams", "3653965885", "639 Point Drive");
		contact.setAddress("256 N 35 E Full Moon");
		assertTrue(contact.getAddress().equals("256 N 35 E Full Moon"));
	}
	
	//address is too long
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "3653565885", "25 S Lane Yellow Circle Drive N");
		});
	}
	//(setter) address is too long
	@Test
	void testAddressTooLongSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setAddress("25 S Lane Yellow Circle Drive N");
		});
	}
		
	//address is a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testAddressOverTheLimitWhitespaces() {
		Assertions.assertDoesNotThrow(() -> {
			new Contact("Johnathan", "Smith", "3653565885", "25 S Lane Yellow Circle Drive  ");
		});
	}
	//(setter) address is a correct length with the extra leading whitespace, shouldn't throw any exceptions
	@Test
	void testAddressOverTheLimitWhitespacesSetter() {
		Contact contact = new Contact("John", "Smith", "3653565885", "25 S Lane Yellow");
		contact.setAddress(" 639 Point Drive   ");
		assertTrue(contact.getAddress().equals("639 Point Drive"));
	}
		
	//address is null
	@Test
	void testAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "3653565885", null);
		});
	}
	//(setter) address is null
	@Test
	void testAddressIsNullSetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setAddress(null);
		});
	}
		
	//address is empty
	@Test
	void testAddressIsEmpty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("Johnathan", "Smith", "3653565885", " ");
		});
	}
	//(setter)address is empty
	@Test
	void testAddressIsEmptySetter() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact("Johnathan", "Smith", "3653565885", "25 S Lane Yellow");
			contact.setAddress("");
		});
	}
	

}
